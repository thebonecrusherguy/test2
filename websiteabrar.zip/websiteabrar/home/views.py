from django.shortcuts import render
from .models import Project
from django.conf.urls.static import static


def home(request):
    Projects = Project.objects.all()
    return render(request, 'pp/home.html', {'projects':Projects})
