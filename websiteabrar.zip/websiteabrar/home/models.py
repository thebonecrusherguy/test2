from django.db import models

class Project(models.Model):
    title=models.CharField(max_length=100)
    Description=models.CharField(max_length=200)
    image=models.ImageField(upload_to='portfolio_abrar/static/media/images')
    url=models.URLField(blank=True)
